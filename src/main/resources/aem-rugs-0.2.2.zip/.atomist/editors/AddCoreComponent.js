var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var EditorFunctions_1 = require("./EditorFunctions");
var Constants_1 = require("./Constants");
var componentMappings = {
    "breadcrumb": "core/wcm/components/breadcrumb/v1/breadcrumb",
    "button": "core/wcm/components/form/button/v1/button",
    "formcontainer": "core/wcm/components/form/container/v1/container",
    "hidden": "core/wcm/components/form/hidden/v1/hidden",
    "options": "core/wcm/components/form/options/v1/options",
    "textfield": "core/wcm/components/form/text/v1/text",
    "image": "core/wcm/components/image/v1/image",
    "list": "core/wcm/components/list/v1/list",
    "sharing": "core/wcm/components/sharing/v1/sharing",
    "text": "core/wcm/components/text/v1/text"
};
var coreComponentBundleGroupId = "com.adobe.cq";
var coreComponentBundleArtifactId = "core.wcm.components.core";
var coreComponentBundleVersion = "1.0.0";
var AddCoreComponent = (function () {
    function AddCoreComponent() {
    }
    AddCoreComponent.prototype.edit = function (project) {
        var absoluteComponentFolderName = "/apps/" + this.component_folder_name;
        var jcrRootPath = EditorFunctions_1.findContentPackageFolderWithFilterCovering(project, absoluteComponentFolderName);
        if (!jcrRootPath) {
            project.fail("Could not find content package project with filter covering '" + absoluteComponentFolderName + "'.");
            return;
        }
        var componentName = EditorFunctions_1.createNodeNameFromTitle(this.component_title);
        var componentPath = absoluteComponentFolderName + "/" + componentName;
        var relativeComponentPath = componentPath.substring(6);
        var componentFolder = "" + jcrRootPath + componentPath;
        project.addFile(componentFolder + "/.content.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<jcr:root\n    xmlns:sling=\"http://sling.apache.org/jcr/sling/1.0\"\n    xmlns:jcr=\"http://www.jcp.org/jcr/1.0\"\n    jcr:primaryType=\"cq:Component\"\n    componentGroup=\"" + this.component_group + "\"\n    sling:resourceSuperType=\"" + componentMappings[this.core_component_name] + "\"\n    jcr:title=\"" + this.component_title + "\"/>");
        if (this.core_component_name === "image") {
            project.merge("components/image/_cq_editConfig.xml.vm", componentFolder + "/_cq_editConfig.xml", {
                componentType: relativeComponentPath
            });
        }
        EditorFunctions_1.editMatchingProjectsAndParents(project, function (pom) {
            return pom.packaging() === "bundle";
        }, function (pom) {
            pom.addOrReplaceDependency(coreComponentBundleGroupId, coreComponentBundleArtifactId);
        }, function (pom) {
            console.log("add/replace dependencyManagement in " + pom.path());
            pom.addOrReplaceDependencyManagementDependency(coreComponentBundleGroupId, coreComponentBundleArtifactId, "<dependency>\n            <groupId>" + coreComponentBundleGroupId + "</groupId>\n            <artifactId>" + coreComponentBundleArtifactId + "</artifactId>\n            <version>" + coreComponentBundleVersion + "</version>\n            <scope>provided</scope>\n        </dependency>");
        });
    };
    return AddCoreComponent;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Component folder",
        description: "a folder (relative to /apps) into which the proxy component will be created",
        pattern: Constants_1.AemPattern.relativeFolder,
        validInput: "a folder name relative to /apps",
        minLength: 1,
        maxLength: 200
    }),
    __metadata("design:type", String)
], AddCoreComponent.prototype, "component_folder_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Component group",
        description: "the component group name",
        pattern: Constants_1.AemPattern.componentGroup,
        validInput: "a component group name",
        minLength: 1,
        maxLength: 30
    }),
    __metadata("design:type", String)
], AddCoreComponent.prototype, "component_group", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Core component name",
        description: "the core component name (one of " + Object.keys(componentMappings).join(", ") + ")",
        pattern: "^" + Object.keys(componentMappings).join(("|")) + "$",
        validInput: "a component name (one of " + Object.keys(componentMappings).join(", ") + ")",
        minLength: 1,
        maxLength: 30
    }),
    __metadata("design:type", String)
], AddCoreComponent.prototype, "core_component_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "New component title",
        description: "the newly created component's title",
        pattern: RugOperation_1.Pattern.any,
        validInput: "a component title",
        minLength: 1,
        maxLength: 30
    }),
    __metadata("design:type", String)
], AddCoreComponent.prototype, "component_title", void 0);
AddCoreComponent = __decorate([
    Decorators_1.Editor("AddCoreComponent", "Add a proxy component for one of the core components to an AEM project."),
    Decorators_1.Tags("adobe", "aem")
], AddCoreComponent);
exports.AddCoreComponent = AddCoreComponent;
exports.addCoreComponent = new AddCoreComponent();
//# sourceMappingURL=AddCoreComponent.js.map