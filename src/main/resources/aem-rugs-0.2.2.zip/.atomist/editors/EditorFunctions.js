Object.defineProperty(exports, "__esModule", { value: true });
var xmldom_1 = require("xmldom");
function addFilterEntry(filterXml, path) {
    filterXml.addChildNode("/workspaceFilter", "filter", "<filter root=\"" + path + "\"/>");
}
exports.addFilterEntry = addFilterEntry;
function addFilterEntryToDefinition(definitionXml, path) {
    var doc = new xmldom_1.DOMParser().parseFromString(definitionXml.content(), "text/xml");
    var filterElement = findDefinitionFilter(doc.documentElement);
    if (filterElement) {
        var filterCount = countChildNodes(filterElement);
        var newFilterEntry = doc.createElement("f" + filterCount);
        newFilterEntry.setAttributeNS("http://www.jcp.org/jcr/1.0", "jcr:primaryType", "nt:unstructured");
        newFilterEntry.setAttribute("mode", "replace");
        newFilterEntry.setAttribute("root", path);
        newFilterEntry.setAttribute("rules", "[]");
        filterElement.appendChild(newFilterEntry);
        definitionXml.setContent(doc.toString());
    }
    else {
        console.warn("No filter element found in definition/.content.xml. Skipping adding a filter entry.");
    }
}
exports.addFilterEntryToDefinition = addFilterEntryToDefinition;
function findContentPackageFolderWithFilterCovering(project, path) {
    var eng = project.context().pathExpressionEngine();
    var result;
    eng.with(project, "/EveryPom()", function (pom) {
        if (pom.packaging() === "content-package") {
            var basePath_1 = pom.path().substring(0, pom.path().lastIndexOf("/"));
            eng.with(project, "/Xml()", function (xml) {
                var tailMatch = xml.path().match("META\-INF/vault/filter\.xml$");
                if (tailMatch && xml.underPath(basePath_1)) {
                    var doc = new xmldom_1.DOMParser().parseFromString(xml.content(), "text/xml");
                    var filters = doc.getElementsByTagName("filter");
                    for (var _i = 0, filters_1 = filters; _i < filters_1.length; _i++) {
                        var filter = filters_1[_i];
                        var root = filter.getAttribute("root").toString();
                        if (path.indexOf(root) == 0) {
                            result = xml.path().substring(0, tailMatch.index) + "jcr_root";
                        }
                    }
                }
            });
        }
    });
    return result;
}
exports.findContentPackageFolderWithFilterCovering = findContentPackageFolderWithFilterCovering;
function createNodeNameFromTitle(title) {
    return camelCase(title);
}
exports.createNodeNameFromTitle = createNodeNameFromTitle;
function addOrReplaceBuildPluginManagementPlugin(pom, groupId, artifactId, pluginContent) {
    addPluginManagementIfNotPresent(pom);
    pom.addOrReplaceNode("/project/build/pluginManagement/plugins", "/project/build/pluginManagement/plugins/plugin/artifactId [text()='" + artifactId + "' and ../groupId [text() = '" + groupId + "']]/..", "plugin", pluginContent);
}
exports.addOrReplaceBuildPluginManagementPlugin = addOrReplaceBuildPluginManagementPlugin;
function addPluginManagementIfNotPresent(pom) {
    pom.addNodeIfNotPresent("/project/build", "/project/build/pluginManagement", "pluginManagement", "<pluginManagement><plugins></plugins></pluginManagement>");
}
exports.addPluginManagementIfNotPresent = addPluginManagementIfNotPresent;
function editMatchingProjectsAndParents(root, matchF, projectF, parentF) {
    var allProjects = {};
    var allMatchingProjects = [];
    var eng = root.context().pathExpressionEngine();
    eng.with(root, "/EveryPom()", function (pom) {
        var key = pom.groupId() + ":" + pom.artifactId();
        allProjects[key] = pom;
        if (matchF(pom)) {
            allMatchingProjects.push(pom);
        }
    });
    for (var _i = 0, allMatchingProjects_1 = allMatchingProjects; _i < allMatchingProjects_1.length; _i++) {
        var pom = allMatchingProjects_1[_i];
        projectF(pom);
        var parentKey = pom.parentGroupId() + ":" + pom.parentArtifactId();
        var parentPom = allProjects[parentKey];
        if (parentPom != null) {
            parentF(parentPom);
        }
        else {
            parentF(pom);
        }
    }
}
exports.editMatchingProjectsAndParents = editMatchingProjectsAndParents;
function findDefinitionFilter(documentElement) {
    for (var _i = 0, _a = documentElement.childNodes; _i < _a.length; _i++) {
        var child = _a[_i];
        if (child.nodeName === "filter") {
            return child;
        }
    }
    return null;
}
function countChildNodes(element) {
    var count = 0;
    for (var _i = 0, _a = element.childNodes; _i < _a.length; _i++) {
        var child = _a[_i];
        if (child.nodeType === element.nodeType) {
            count++;
        }
    }
    return count;
}
function preserveCamelCase(str) {
    var isLastCharLower = false;
    var isLastCharUpper = false;
    var isLastLastCharUpper = false;
    for (var i = 0; i < str.length; i++) {
        var c = str.charAt(i);
        if (isLastCharLower && (/[a-zA-Z]/).test(c) && c.toUpperCase() === c) {
            str = str.substr(0, i) + '-' + str.substr(i);
            isLastCharLower = false;
            isLastLastCharUpper = isLastCharUpper;
            isLastCharUpper = true;
            i++;
        }
        else if (isLastCharUpper && isLastLastCharUpper && (/[a-zA-Z]/).test(c) && c.toLowerCase() === c) {
            str = str.substr(0, i - 1) + '-' + str.substr(i - 1);
            isLastLastCharUpper = isLastCharUpper;
            isLastCharUpper = false;
            isLastCharLower = true;
        }
        else {
            isLastCharLower = c.toLowerCase() === c;
            isLastLastCharUpper = isLastCharUpper;
            isLastCharUpper = c.toUpperCase() === c;
        }
    }
    return str;
}
function camelCase(str) {
    if (str.length === 0) {
        return '';
    }
    if (str.length === 1) {
        return str.toLowerCase();
    }
    str = preserveCamelCase(str);
    return str
        .replace(/^[_.\- ]+/, '')
        .toLowerCase()
        .replace(/[_.\- ]+(\w|$)/g, function (m, p1) { return p1.toUpperCase(); });
}
exports.camelCase = camelCase;
;
//# sourceMappingURL=EditorFunctions.js.map