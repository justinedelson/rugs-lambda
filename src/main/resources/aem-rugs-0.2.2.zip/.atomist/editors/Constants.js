Object.defineProperty(exports, "__esModule", { value: true });
var Dependency_1 = require("./Dependency");
var XPaths = (function () {
    function XPaths() {
    }
    return XPaths;
}());
XPaths.bsn = "/project/build/plugins/plugin[artifactId/text()='maven-bundle-plugin']/configuration/instructions/Bundle-SymbolicName";
XPaths.embeddeds = "/project/build/plugins/plugin[artifactId/text()='content-package-maven-plugin']/configuration/embeddeds";
XPaths.contentPackageGroup = "/project/build/plugins/plugin[artifactId/text()='content-package-maven-plugin']/configuration/group";
XPaths.slingInstallUrl = "/project/build/plugins/plugin[artifactId/text()='maven-sling-plugin']/configuration/slingUrl";
exports.XPaths = XPaths;
var Dependencies = (function () {
    function Dependencies() {
    }
    return Dependencies;
}());
Dependencies.osgiCore420 = new Dependency_1.Dependency("org.osgi", "org.osgi.core", "4.2.0");
Dependencies.osgiCompendium420 = new Dependency_1.Dependency("org.osgi", "org.osgi.compendium", "4.2.0");
Dependencies.scrAnnotations = new Dependency_1.Dependency("org.apache.felix", "org.apache.felix.scr.annotations", "1.9.8");
Dependencies.bndAnnotations = new Dependency_1.Dependency("biz.aQute.bnd", "annotation", "2.3.0");
Dependencies.servletApi = new Dependency_1.Dependency("javax.servlet", "servlet-api", "2.5");
Dependencies.commonsLang3 = new Dependency_1.Dependency("org.apache.commons", "commons-lang3", "3.0.1");
Dependencies.commonsLang2 = new Dependency_1.Dependency("commons-lang", "commons-lang", "2.5");
Dependencies.commonsCodec = new Dependency_1.Dependency("commons-codec", "commons-codec", "1.5");
Dependencies.commonsIo = new Dependency_1.Dependency("commons-io", "commons-io", "2.4");
Dependencies.jstl = new Dependency_1.Dependency("com.day.commons", "day-commons-jstl", "1.1.4");
Dependencies.jsp = new Dependency_1.Dependency("javax.servlet.jsp", "jsp-api", "2.1");
Dependencies.jcr = new Dependency_1.Dependency("javax.jcr", "jcr", "2.0");
Dependencies.junit = new Dependency_1.Dependency("junit", "junit", "4.11", "jar", "test");
Dependencies.junitAddons = new Dependency_1.Dependency("junit-addons", "junit-addons", "1.4", "jar", "test");
Dependencies.slf4j = new Dependency_1.Dependency("org.slf4j", "slf4j-api", "1.7.6");
Dependencies.slf4jSimple = new Dependency_1.Dependency("org.slf4j", "slf4j-simple", "1.7.6", "jar", "test");
Dependencies.wcmTaglib = new Dependency_1.Dependency("com.day.cq.wcm", "cq-wcm-taglib", "5.6.4");
Dependencies.slingTaglib = new Dependency_1.Dependency("org.apache.sling", "org.apache.sling.scripting.jsp.taglib", "2.2.0");
exports.Dependencies = Dependencies;
var AemPattern = (function () {
    function AemPattern() {
    }
    return AemPattern;
}());
AemPattern.componentGroup = "^[a-zA-Z][-\\w. ]+$";
AemPattern.relativeFolder = "^[\\w]+[-\\w\\/]+$";
exports.AemPattern = AemPattern;
//# sourceMappingURL=Constants.js.map