var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var EditorFunctions_1 = require("./EditorFunctions");
var pluginGroupId = "org.apache.sling";
var pluginArtifactId = "htl-maven-plugin";
var pluginVersion = "1.0.6";
var AddHtlMavenPlugin = (function () {
    function AddHtlMavenPlugin() {
    }
    AddHtlMavenPlugin.prototype.edit = function (project) {
        EditorFunctions_1.editMatchingProjectsAndParents(project, function (pom) {
            return pom.packaging() === "content-package";
        }, function (pom) {
            pom.addOrReplaceBuildPlugin(pluginGroupId, pluginArtifactId, "<plugin>\n                <groupId>org.apache.sling</groupId>\n                <artifactId>htl-maven-plugin</artifactId>\n            </plugin>");
        }, function (pom) {
            EditorFunctions_1.addOrReplaceBuildPluginManagementPlugin(pom, pluginGroupId, pluginArtifactId, "<plugin>\n                    <groupId>" + pluginGroupId + "</groupId>\n                    <artifactId>" + pluginArtifactId + "</artifactId>\n                    <version>" + pluginVersion + "</version>\n                    <configuration>\n                        <failOnWarnings>true</failOnWarnings>\n                    </configuration>\n                    <executions>\n                        <execution>\n                            <goals>\n                                <goal>validate</goal>\n                            </goals>\n                        </execution>\n                    </executions>\n                </plugin>");
        });
    };
    return AddHtlMavenPlugin;
}());
AddHtlMavenPlugin = __decorate([
    Decorators_1.Editor("AddHtlMavenPlugin", "Adds the HTL Maven Plugin to Content Package projects"),
    Decorators_1.Tags("adobe", "aem")
], AddHtlMavenPlugin);
exports.AddHtlMavenPlugin = AddHtlMavenPlugin;
exports.addHtlMavenPlugin = new AddHtlMavenPlugin();
//# sourceMappingURL=AddHtlMavenPlugin.js.map