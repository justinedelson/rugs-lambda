Object.defineProperty(exports, "__esModule", { value: true });
var Dependency = (function () {
    function Dependency(groupId, artifactId, version, type, scope, classifier) {
        if (type === void 0) { type = "jar"; }
        if (scope === void 0) { scope = "provided"; }
        if (classifier === void 0) { classifier = ""; }
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.scope = scope;
        this.classifier = classifier;
    }
    Dependency.prototype.addOrReplaceDependencyManagement = function (pom) {
        pom.addOrReplaceDependencyManagementDependency(this.groupId, this.artifactId, this.getXml());
    };
    Dependency.prototype.addOrReplaceManagedDependency = function (pom) {
        if (this.classifier === "") {
            pom.addOrReplaceDependency(this.groupId, this.artifactId);
        }
        else {
            pom.addOrReplaceNode("/project/dependencies", "/project/dependencies/dependency/artifactId[text()='" + this.artifactId + "' and ../groupId[text() = '" + this.groupId + "' and ../classifier[text() = '" + this.classifier + "']]]/..", "dependency", "<dependency><groupId>" + this.groupId + "</groupId><artifactId>" + this.artifactId + "</artifactId><classifier>" + this.classifier + "</classifier></dependency>");
        }
    };
    Dependency.prototype.getXml = function () {
        if (this.classifier === "") {
            return "<dependency>\n            <groupId>" + this.groupId + "</groupId>\n            <artifactId>" + this.artifactId + "</artifactId>\n            <version>" + this.version + "</version>\n            <scope>" + this.scope + "</scope>\n        </dependency>";
        }
        else {
            return "<dependency>\n            <groupId>" + this.groupId + "</groupId>\n            <artifactId>" + this.artifactId + "</artifactId>\n            <version>" + this.version + "</version>\n            <scope>" + this.scope + "</scope>\n            <classifier>" + this.classifier + "</classifier>\n        </dependency>";
        }
    };
    return Dependency;
}());
exports.Dependency = Dependency;
//# sourceMappingURL=Dependency.js.map