var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var GeneratorFunctions_1 = require("./GeneratorFunctions");
var EditorFunctions_1 = require("./../editors/EditorFunctions");
var Constants_1 = require("./../editors/Constants");
var CreateAemMultimoduleProject = (function () {
    function CreateAemMultimoduleProject() {
        this.version = "0.0.1-SNAPSHOT";
    }
    CreateAemMultimoduleProject.prototype.updateReadme = function (project) {
        console.log("Updating README.md");
        var eng = project.context().pathExpressionEngine();
        var readMePE = new PathExpression_1.PathExpression("/*[@name='README.md']");
        var readMe = eng.scalar(project, readMePE);
        readMe.replace("${projectName}", project.name());
    };
    CreateAemMultimoduleProject.prototype.updatePoms = function (project) {
        var _this = this;
        console.log("Updating POM files");
        var eng = project.context().pathExpressionEngine();
        eng.with(project, "/Pom()", function (pom) {
            pom.setArtifactId(project.name());
            pom.setGroupId(_this.group_id);
            pom.setVersion(_this.version);
            pom.setProjectName(project.name() + " - Reactor Project");
            pom.setDescription("Maven Multimodule project for " + project.name() + ".");
            GeneratorFunctions_1.addDependencyManagement(_this.aem_version, pom);
        });
        eng.with(project, "/*/*[@name='pom.xml']/Pom()", function (pom) {
            pom.setParentArtifactId(project.name());
            pom.setParentGroupId(_this.group_id);
            pom.setParentVersion(_this.version);
            if (pom.packaging() === "bundle") {
                pom.setArtifactId(_this.bundleArtifactId);
                pom.setProjectName(project.name() + " Bundle");
                pom.setTextContentFor(Constants_1.XPaths.bsn, _this.group_id + "." + project.name());
                pom.setTextContentFor(Constants_1.XPaths.slingInstallUrl, "http://${aem.host}:${aem.port}/apps/" + _this.apps_folder_name + "/install");
                GeneratorFunctions_1.addBundleDependencies(_this.aem_version, pom);
            }
            else if (pom.packaging() === "content-package") {
                pom.setArtifactId(_this.contentArtifactId);
                pom.setProjectName(project.name() + " Content Package");
                pom.addOrReplaceDependencyOfVersion(_this.group_id, _this.bundleArtifactId, "${project.version}");
                GeneratorFunctions_1.addContentPackageDependencies(_this.aem_version, pom);
                pom.addChildNode(Constants_1.XPaths.embeddeds, "embedded", "<embedded>\n                            <groupId>" + _this.group_id + "</groupId>\n                            <artifactId>" + _this.bundleArtifactId + "</artifactId>\n                            <target>/apps/" + _this.apps_folder_name + "/install</target>\n                        </embedded>");
                pom.setTextContentFor(Constants_1.XPaths.contentPackageGroup, _this.content_package_group);
            }
        });
    };
    CreateAemMultimoduleProject.prototype.updateVaultFiles = function (project) {
        var _this = this;
        console.log("Updating Vault files");
        var eng = project.context().pathExpressionEngine();
        eng.with(project, "/Xml()", function (xml) {
            if (xml.path() === "ui.apps/src/main/content/META-INF/vault/properties.xml") {
                GeneratorFunctions_1.setProperty(xml, 'version', _this.version);
                GeneratorFunctions_1.setProperty(xml, 'description', project.name() + " Content Package");
                GeneratorFunctions_1.setProperty(xml, 'group', _this.content_package_group);
                GeneratorFunctions_1.setProperty(xml, 'name', project.name());
                GeneratorFunctions_1.setProperty(xml, 'path', "/etc/packages/" + _this.content_package_group + "/" + project.name() + "-" + _this.version + ".zip");
            }
            else if (xml.path() === "ui.apps/src/main/content/META-INF/vault/filter.xml") {
                EditorFunctions_1.addFilterEntry(xml, "/apps/" + _this.apps_folder_name);
            }
        });
        eng.with(project, "//definition/*[@name='.content.xml']", function (file) {
            file.replace('cqVersion="REPLACE"', "cqVersion=\"" + _this.aem_version + "\"");
            file.replace('group="REPLACE"', "group=\"" + _this.content_package_group + "\"");
            file.replace('name="REPLACE"', "name=\"" + project.name() + "\"");
            file.replace('path="REPLACE"', "path=\"/etc/packages/" + _this.content_package_group + "/" + project.name() + "-" + _this.version + "\"");
            file.replace('version="REPLACE"', "version=\"" + _this.version + "\"");
            EditorFunctions_1.addFilterEntryToDefinition(file, "/apps/" + _this.apps_folder_name);
        });
    };
    CreateAemMultimoduleProject.prototype.populate = function (project) {
        console.log("Creating " + project.name());
        this.bundleArtifactId = project.name() + ".core";
        this.contentArtifactId = project.name() + ".ui.apps";
        GeneratorFunctions_1.removeUnnecessaryFiles(project, ["NOTICE", "LICENSE", "CHANGELOG.md", "CODE_OF_CONDUCT.md", "README.md"]);
        project.copyEditorBackingFilesWithNewRelativePath(".atomist/templates/multimodule-project", "");
        this.updateReadme(project);
        this.updatePoms(project);
        this.updateVaultFiles(project);
        project.addDirectory("java", "core/src/main");
        project.addDirectory("java", "core/src/test");
        project.addDirectory("jcr_root", "ui.apps/src/main/content");
        project.addFile("ui.apps/src/main/content/jcr_root/apps/" + this.apps_folder_name + "/install/.vltignore", "*.jar");
    };
    return CreateAemMultimoduleProject;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Group ID",
        description: "the Maven Group ID for the generated project",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "A Maven Group ID",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], CreateAemMultimoduleProject.prototype, "group_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Content Package Group",
        description: "a Group for your Package when it is installed in the AEM Package Manager",
        pattern: RugOperation_1.Pattern.any,
        validInput: "a Group",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], CreateAemMultimoduleProject.prototype, "content_package_group", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "/apps folder",
        description: "a folder under /apps in which components and configs will be created",
        pattern: RugOperation_1.Pattern.java_identifier,
        validInput: "a folder name",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], CreateAemMultimoduleProject.prototype, "apps_folder_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "AEM Version",
        description: "An AEM version (must be one of 6.1, 6.2 or 6.3).",
        pattern: "^6\.1|6\.2|6\.3$",
        validInput: "a supported AEM Version",
        minLength: 3,
        maxLength: 3
    }),
    __metadata("design:type", String)
], CreateAemMultimoduleProject.prototype, "aem_version", void 0);
CreateAemMultimoduleProject = __decorate([
    Decorators_1.Generator("CreateAemMultimoduleProject", "Create a skeletal AEM project"),
    Decorators_1.Tags("adobe", "aem")
], CreateAemMultimoduleProject);
exports.CreateAemMultimoduleProject = CreateAemMultimoduleProject;
exports.createAemMultimoduleProject = new CreateAemMultimoduleProject();
//# sourceMappingURL=CreateAemMultimoduleProject.js.map