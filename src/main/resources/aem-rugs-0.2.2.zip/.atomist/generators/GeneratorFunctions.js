Object.defineProperty(exports, "__esModule", { value: true });
var Constants_1 = require("./../editors/Constants");
var Dependency_1 = require("./../editors/Dependency");
function removeUnnecessaryFiles(project, extraFiles, extraDirectories) {
    var filesToRemove = [
        ".atomist.yml",
        ".travis.yml",
        ".gitignore"
    ];
    if (extraFiles != null) {
        filesToRemove = filesToRemove.concat(extraFiles);
    }
    for (var _i = 0, filesToRemove_1 = filesToRemove; _i < filesToRemove_1.length; _i++) {
        var f = filesToRemove_1[_i];
        project.deleteFile(f);
    }
    var directoriesToRemove = [
        ".idea"
    ];
    if (extraDirectories != null) {
        directoriesToRemove = directoriesToRemove.concat(extraDirectories);
    }
    for (var _a = 0, directoriesToRemove_1 = directoriesToRemove; _a < directoriesToRemove_1.length; _a++) {
        var d = directoriesToRemove_1[_a];
        project.deleteDirectory(d);
    }
}
exports.removeUnnecessaryFiles = removeUnnecessaryFiles;
function setProperty(xml, name, value) {
    xml.setTextContentFor("/properties/entry[@key='" + name + "']", value);
}
exports.setProperty = setProperty;
function addDependencyManagement(aemVersion, pom) {
    var dependencies = [
        Constants_1.Dependencies.osgiCore420,
        Constants_1.Dependencies.osgiCompendium420,
        Constants_1.Dependencies.scrAnnotations,
        Constants_1.Dependencies.bndAnnotations,
        Constants_1.Dependencies.servletApi,
        Constants_1.Dependencies.commonsLang3,
        Constants_1.Dependencies.commonsLang2,
        Constants_1.Dependencies.commonsCodec,
        Constants_1.Dependencies.commonsIo,
        Constants_1.Dependencies.jstl,
        Constants_1.Dependencies.jsp,
        Constants_1.Dependencies.jcr,
        Constants_1.Dependencies.slf4j,
        Constants_1.Dependencies.wcmTaglib,
        Constants_1.Dependencies.slingTaglib
    ];
    var testDependencies = [
        Constants_1.Dependencies.junit,
        Constants_1.Dependencies.junitAddons,
        Constants_1.Dependencies.slf4jSimple
    ];
    dependencies.push(getUberJar(aemVersion));
    var allDependencies = dependencies.concat(testDependencies);
    for (var _i = 0, allDependencies_1 = allDependencies; _i < allDependencies_1.length; _i++) {
        var d = allDependencies_1[_i];
        d.addOrReplaceDependencyManagement(pom);
    }
}
exports.addDependencyManagement = addDependencyManagement;
function addContentPackageDependencies(aemVersion, pom) {
    var dependencies = [
        Constants_1.Dependencies.osgiCore420,
        Constants_1.Dependencies.osgiCompendium420,
        Constants_1.Dependencies.servletApi,
        Constants_1.Dependencies.commonsLang3,
        Constants_1.Dependencies.commonsLang2,
        Constants_1.Dependencies.jstl,
        Constants_1.Dependencies.jsp,
        Constants_1.Dependencies.jcr,
        Constants_1.Dependencies.slf4j,
        Constants_1.Dependencies.wcmTaglib,
        Constants_1.Dependencies.slingTaglib
    ];
    dependencies.push(getUberJar(aemVersion));
    for (var _i = 0, dependencies_1 = dependencies; _i < dependencies_1.length; _i++) {
        var d = dependencies_1[_i];
        d.addOrReplaceManagedDependency(pom);
    }
}
exports.addContentPackageDependencies = addContentPackageDependencies;
function addBundleDependencies(aemVersion, pom) {
    var dependencies = [
        Constants_1.Dependencies.osgiCore420,
        Constants_1.Dependencies.osgiCompendium420,
        Constants_1.Dependencies.scrAnnotations,
        Constants_1.Dependencies.bndAnnotations,
        Constants_1.Dependencies.servletApi,
        Constants_1.Dependencies.commonsLang3,
        Constants_1.Dependencies.commonsLang2,
        Constants_1.Dependencies.commonsCodec,
        Constants_1.Dependencies.commonsIo,
        Constants_1.Dependencies.jsp,
        Constants_1.Dependencies.jcr,
        Constants_1.Dependencies.slf4j
    ];
    var testDependencies = [
        Constants_1.Dependencies.junit,
        Constants_1.Dependencies.junitAddons,
        Constants_1.Dependencies.slf4jSimple
    ];
    dependencies.push(getUberJar(aemVersion));
    var allDependencies = dependencies.concat(testDependencies);
    for (var _i = 0, allDependencies_2 = allDependencies; _i < allDependencies_2.length; _i++) {
        var d = allDependencies_2[_i];
        d.addOrReplaceManagedDependency(pom);
    }
}
exports.addBundleDependencies = addBundleDependencies;
function getUberJar(aemVersion) {
    switch (aemVersion) {
        case "6.1":
            return new Dependency_1.Dependency("com.adobe.aem", "uber-jar", "6.1.0", "jar", "provided", "obfuscated-apis");
        case "6.2":
            return new Dependency_1.Dependency("com.adobe.aem", "uber-jar", "6.2.0", "jar", "provided", "apis");
        case "6.3":
            return new Dependency_1.Dependency("com.adobe.aem", "uber-jar", "6.3.0", "jar", "provided", "apis");
    }
}
//# sourceMappingURL=GeneratorFunctions.js.map