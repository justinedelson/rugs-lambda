Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var xmldom_1 = require("xmldom");
var xpathSelect = require("xpath.js");
function countDependenciesInDependencyManagement(pom) {
    var doc = new xmldom_1.DOMParser().parseFromString(pom.content(), "text/xml");
    return doc.getElementsByTagName("dependencyManagement")[0].getElementsByTagName("dependency").length;
}
exports.countDependenciesInDependencyManagement = countDependenciesInDependencyManagement;
function getAttributeValue(file, xpath) {
    var doc = new xmldom_1.DOMParser().parseFromString(file.content());
    var xpathResult = xpathSelect(doc, xpath);
    if (xpathResult.length == 1) {
        return xpathResult[0].value;
    }
    return null;
}
exports.getAttributeValue = getAttributeValue;
function addCommonSteps() {
    Core_1.Given("a simple multimodule project", function (project, world) {
        project.copyEditorBackingFilesWithNewRelativePath(".atomist/templates/test-projects/multimodule", "");
    });
    Core_1.Given("a multimodule project with two content packages", function (project, world) {
        project.copyEditorBackingFilesWithNewRelativePath(".atomist/templates/test-projects/multimodule-two-content-packages", "");
    });
    Core_1.Given("a standalone content-package project", function (project, world) {
        project.copyEditorBackingFilesWithNewRelativePath(".atomist/templates/test-projects/just-content-package", "");
    });
    Core_1.Given("a standalone bundle project", function (project, world) {
        project.copyEditorBackingFilesWithNewRelativePath(".atomist/templates/test-projects/just-bundle", "");
    });
    Core_1.Given("a multimodule project with a separate parent", function (project, world) {
        project.copyEditorBackingFilesWithNewRelativePath(".atomist/templates/test-projects/multimodule-with-separate-parent", "");
    });
}
exports.addCommonSteps = addCommonSteps;
//# sourceMappingURL=TestHelpers.js.map