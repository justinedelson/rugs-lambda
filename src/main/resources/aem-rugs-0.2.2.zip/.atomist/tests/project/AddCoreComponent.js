Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var Result_1 = require("@atomist/rug/test/Result");
var TestHelpers_1 = require("./TestHelpers");
TestHelpers_1.addCommonSteps();
Core_1.When("add core text component", function (project, world) {
    var editor = world.editor("AddCoreComponent");
    world.editWith(editor, {
        component_folder_name: "test/components/content",
        component_group: "My Project",
        core_component_name: "text",
        component_title: "My Text"
    });
});
Core_1.When("add core image component", function (project, world) {
    var editor = world.editor("AddCoreComponent");
    world.editWith(editor, {
        component_folder_name: "test/components/content",
        component_group: "My Project",
        core_component_name: "image",
        component_title: "My Image"
    });
});
Core_1.Then("the text component should be created in the uiapps project", function (project, world) {
    return checkTextComponent(project, "uiapps/src/main/content/jcr_root/apps/test/components/content/myText/.content.xml");
});
Core_1.Then("the text component should be created in the root project", function (project, world) {
    return checkTextComponent(project, "src/main/content/jcr_root/apps/test/components/content/myText/.content.xml");
});
Core_1.Then("the text component should not be created in the uiconfig project", function (project, world) {
    var path = "uiconfig/src/main/content/jcr_root/apps/test/components/content/myText/.content.xml";
    if (project.fileExists(path)) {
        return Result_1.Result.Failure("Component created at the incorrect path");
    }
    else {
        return Result_1.Result.Success;
    }
});
Core_1.Then("the image component should be created in the root project", function (project, world) {
    return checkImageComponent(project, "src/main/content/jcr_root/apps/test/components/content/myImage/.content.xml");
});
Core_1.Then("the image component in the root project should have the correct editConfig", function (project, world) {
    var file = project.findFile("src/main/content/jcr_root/apps/test/components/content/myImage/_cq_editConfig.xml");
    var value = TestHelpers_1.getAttributeValue(file, "/jcr:root/cq:dropTargets/image/parameters/@sling:resourceType");
    if ("test/components/content/myImage" === value) {
        return Result_1.Result.Success;
    }
    else {
        return Result_1.Result.Failure("unexpected resourceType in cq:EditConfig: " + value);
    }
});
Core_1.Then("the core component bundle should be added to the core project", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/core/*[@name='pom.xml']/Pom()"));
    return pom.isDependencyPresent("com.adobe.cq", "core.wcm.components.core");
});
Core_1.Then("the core component bundle should be added to the root project", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/Pom()"));
    return pom.isDependencyPresent("com.adobe.cq", "core.wcm.components.core");
});
Core_1.Then("the core component bundle should be managed in the root project", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/Pom()"));
    return pom.isDependencyManagementDependencyPresent("com.adobe.cq", "core.wcm.components.core");
});
Core_1.Then("the core component bundle should be managed in the parent project", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/parent/*[@name='pom.xml']/Pom()"));
    return pom.isDependencyManagementDependencyPresent("com.adobe.cq", "core.wcm.components.core");
});
function checkTextComponent(project, path) {
    if (project.fileExists(path)) {
        var fileContent = project.findFile(path).content();
        var expected = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<jcr:root\n    xmlns:sling=\"http://sling.apache.org/jcr/sling/1.0\"\n    xmlns:jcr=\"http://www.jcp.org/jcr/1.0\"\n    jcr:primaryType=\"cq:Component\"\n    componentGroup=\"My Project\"\n    sling:resourceSuperType=\"core/wcm/components/text/v1/text\"\n    jcr:title=\"My Text\"/>";
        if (fileContent === expected) {
            return Result_1.Result.Success;
        }
        else {
            return Result_1.Result.Failure("Unexpected content in .content.xml: !" + project.findFile(path).content() + "! Expected: !" + expected + "!");
        }
    }
    else {
        return Result_1.Result.Failure("no component exists at the correct path");
    }
}
function checkImageComponent(project, path) {
    if (project.fileExists(path)) {
        var fileContent = project.findFile(path).content();
        var expected = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<jcr:root\n    xmlns:sling=\"http://sling.apache.org/jcr/sling/1.0\"\n    xmlns:jcr=\"http://www.jcp.org/jcr/1.0\"\n    jcr:primaryType=\"cq:Component\"\n    componentGroup=\"My Project\"\n    sling:resourceSuperType=\"core/wcm/components/image/v1/image\"\n    jcr:title=\"My Image\"/>";
        if (fileContent === expected) {
            return Result_1.Result.Success;
        }
        else {
            return Result_1.Result.Failure("Unexpected content in .content.xml: !" + project.findFile(path).content() + "! Expected: !" + expected + "!");
        }
    }
    else {
        return Result_1.Result.Failure("no component exists at the correct path");
    }
}
//# sourceMappingURL=AddCoreComponent.js.map