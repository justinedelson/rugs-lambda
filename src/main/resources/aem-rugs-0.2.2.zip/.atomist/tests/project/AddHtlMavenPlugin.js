Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var TestHelpers_1 = require("./TestHelpers");
TestHelpers_1.addCommonSteps();
Core_1.When("add HTL plugin", function (project, world) {
    var editor = world.editor("AddHtlMavenPlugin");
    world.editWith(editor, {});
});
Core_1.Then("the root project should have the HTL plugin in pluginManagement", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/Pom()"));
    return pom.contains("/project/build/pluginManagement/plugins/plugin/artifactId [text()='htl-maven-plugin' and ../groupId [text() = 'org.apache.sling']]/..");
});
Core_1.Then("the parent project should have the HTL plugin in pluginManagement", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/parent/*[@name='pom.xml']/Pom()"));
    return pom.contains("/project/build/pluginManagement/plugins/plugin/artifactId [text()='htl-maven-plugin' and ../groupId [text() = 'org.apache.sling']]/..");
});
Core_1.Then("the uiapps project should be configured with the HTL plugin", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/uiapps/*[@name='pom.xml']/Pom()"));
    return pom.contains("/project/build/plugins/plugin/artifactId [text()='htl-maven-plugin' and ../groupId [text() = 'org.apache.sling']]/..");
});
Core_1.Then("the uiconfig project should be configured with the HTL plugin", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/uiconfig/*[@name='pom.xml']/Pom()"));
    return pom.contains("/project/build/plugins/plugin/artifactId [text()='htl-maven-plugin' and ../groupId [text() = 'org.apache.sling']]/..");
});
Core_1.Then("the root project should be configured with the HTL plugin", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/Pom()"));
    return pom.contains("/project/build/plugins/plugin/artifactId [text()='htl-maven-plugin' and ../groupId [text() = 'org.apache.sling']]/..");
});
//# sourceMappingURL=AddHtlMavenPlugin.js.map