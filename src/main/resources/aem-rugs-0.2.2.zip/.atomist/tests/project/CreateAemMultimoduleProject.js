Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var Result_1 = require("@atomist/rug/test/Result");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var TestHelpers_1 = require("./TestHelpers");
var projectName = "test-project";
var groupId = "com.myco";
var contentPackageGroup = "my-packages";
var appsFolderName = "test";
Core_1.When("generate with CreateAemMultimoduleProject for AEM 6.3", function (project, world) {
    var generator = world.generator("CreateAemMultimoduleProject");
    world.generateWith(generator, projectName, {
        group_id: groupId,
        content_package_group: contentPackageGroup,
        apps_folder_name: appsFolderName,
        aem_version: "6.3"
    });
});
Core_1.Then("there should be a correct root pom file for AEM 6.3", function (project, world) {
    var eng = project.context().pathExpressionEngine();
    var pom = eng.scalar(project, new PathExpression_1.PathExpression("/Pom()"));
    if (!pom) {
        return Result_1.Result.Failure("No pom.xml in root");
    }
    if (pom.content().indexOf("REPLACE") > -1) {
        return Result_1.Result.Failure("Expected 'REPLACE' in root pom. " + pom.content());
    }
    if (pom.groupId() !== groupId) {
        return Result_1.Result.Failure("Incorrect groupId: " + pom.groupId());
    }
    if (pom.artifactId() !== projectName) {
        return Result_1.Result.Failure("Incorrect artifactId: " + pom.artifactId());
    }
    var dependencyManagementCount = TestHelpers_1.countDependenciesInDependencyManagement(pom);
    if (dependencyManagementCount != 19) {
        return Result_1.Result.Failure("Incorrect number of dependencies in dependencyManagenent " + dependencyManagementCount);
    }
    return Result_1.Result.Success;
});
//# sourceMappingURL=CreateAemMultimoduleProject.js.map